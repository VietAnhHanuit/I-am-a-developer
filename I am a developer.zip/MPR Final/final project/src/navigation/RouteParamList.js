export const ProtectedScreens = [];
