export const useGetFirebaseToken = () => {
  const getToken = async () => {
    return "";
  };

  return { getToken };
};

export const useNotification = () => {
  const showNotification = async (title, body, onPress) => {};

  return { showNotification };
};
