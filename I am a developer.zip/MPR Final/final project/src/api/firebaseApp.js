// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCuMk-6vTu5o_N4nze0a9UNndy23E_opns",
  authDomain: "dev-simulator-3f587.firebaseapp.com",
  projectId: "dev-simulator-3f587",
  storageBucket: "dev-simulator-3f587.appspot.com",
  messagingSenderId: "678815747720",
  appId: "1:678815747720:web:7930ff0b2bdf185dac593d"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);