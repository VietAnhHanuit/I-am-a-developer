
import * as images from './images';

export { images };
