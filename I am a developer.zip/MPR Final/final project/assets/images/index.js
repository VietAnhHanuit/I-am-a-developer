export const woman = require('./woman.png');
export const man = require('./man.png');
export const dev = require('./dev.png');

export const activity = require('./activity.png');
export const education = require('./education.png');
export const home = require('./home.png');
export const occupation = require('./occupation.png');
export const relationship = require('./relationship.png');

export const happy = require('./happy.png');
export const health = require('./health.png');
export const mind = require('./mind.png');
export const vision = require('./vision.png');

export const book = require('./book.png');
export const school = require('./school.png');
export const lock = require('./lock.png');

export const offer = require('./offer.png');
export const findjob = require('./findjob.png');
export const job = require('./job.png');
export const lighting = require('./lighting.png');
export const company = require('./company.png');
export const leavejob = require('./leavejob.png');

export const askMoney = require('./askMoney.png');
export const compliment = require('./compliment.png');
export const gift = require('./gift.png');
export const insult = require('./insult.png');
export const spendtime = require('./spendtime.png');
export const fight = require('./fight.png');
export const dating = require('./dating.png');


export const logout = require('./logout.png');
export const error = require('./error.png');

export const event = require('./event.png');
export const reward = require('./reward.png');